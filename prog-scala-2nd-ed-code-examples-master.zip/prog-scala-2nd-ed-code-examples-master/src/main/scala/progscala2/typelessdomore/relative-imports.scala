// src/main/scala/progscala2/typelessdomore/relative-imports.scala
import scala.collection.mutable._
import collection.immutable._              // Since "scala" is already imported
import _root_.scala.collection.parallel._  // full path from real "root"

