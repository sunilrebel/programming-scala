// src/main/scala/progscala2/toolslibs/ScriptWrapper.scala

object ScriptWrapper {
  def main(args: Array[String]): Unit = {
    new AnyRef {
      // Your script code is inserted here.
    }
  }
}
